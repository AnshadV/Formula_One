<img align="left" width="80" height="80"
src="app/src/main/ic_launcher-playstore.png" alt="App icon">

# Sayboard

This project provides a voice keyboard using [Vosk](https://alphacephei.com/vosk/android).
It is based on [https://github.com/Felicis/vosk-android-demo](https://github.com/Felicis/vosk-android-demo).

## Roadmap
- Keyboard UI
  - [x] Customize keyboard colors.
  - [ ] Light and dark theme.
  - [ ] Punctuation buttons
- Keyboard Logic
  - [ ] Auto capitalization
  - [ ] Delete whole words at a time

Note: prior to commit [Multiple language support!](https://github.com/ElishaAz/Sayboard/commit/9d61c774e6eb623c2b8603a85a5bd73d98ab9af1),
this repository had another gradle model named `models`. As it is large and not needed anymore, I removed it from git history.
If you want to use any earlier commits, you can find it [here](https://github.com/Felicis/vosk-android-demo/tree/master/models).
