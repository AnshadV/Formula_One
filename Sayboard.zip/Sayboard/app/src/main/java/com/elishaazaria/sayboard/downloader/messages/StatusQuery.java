package com.elishaazaria.sayboard.downloader.messages;

public class StatusQuery {
}
