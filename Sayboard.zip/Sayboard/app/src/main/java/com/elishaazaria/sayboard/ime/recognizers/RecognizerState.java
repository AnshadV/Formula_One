package com.elishaazaria.sayboard.ime.recognizers;

public enum RecognizerState {
    NONE, LOADING, READY, IN_RAM, CLOSED, ERROR
}
