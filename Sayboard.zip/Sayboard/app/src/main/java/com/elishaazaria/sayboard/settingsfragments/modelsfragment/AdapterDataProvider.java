package com.elishaazaria.sayboard.settingsfragments.modelsfragment;

import java.util.List;

public interface AdapterDataProvider {
    List<ModelsAdapterData> getData();
}
